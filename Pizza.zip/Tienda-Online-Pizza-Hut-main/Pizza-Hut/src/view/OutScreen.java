package view;

public class OutScreen {

}
