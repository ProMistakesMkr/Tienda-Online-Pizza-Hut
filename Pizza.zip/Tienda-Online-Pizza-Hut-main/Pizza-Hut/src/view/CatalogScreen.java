package view;

public class CatalogScreen {

}
