package model;

public class Logic {

}
