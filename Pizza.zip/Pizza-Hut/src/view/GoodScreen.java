package view;

public class GoodScreen {

}
